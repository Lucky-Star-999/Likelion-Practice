package com.example.week83;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week83ApplicationTests {

	@Test
	void contextLoads() {
	}

}
